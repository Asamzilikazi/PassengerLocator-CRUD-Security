package za.ac.mzilikazi.Config.Database;

/**
 * Created by Asavela on 2017/08/22.
 */
public class DBConstants {
    public static final String DATABASE_NAME="airportdb";
    public static final int DATABASE_VERSION=1;
}
