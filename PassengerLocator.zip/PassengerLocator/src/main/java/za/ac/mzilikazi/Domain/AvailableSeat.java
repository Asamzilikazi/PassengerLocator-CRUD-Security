package za.ac.mzilikazi.Domain;

/**
 * Created by Asavela on 2017/08/08.
 */
public class AvailableSeat {
}
