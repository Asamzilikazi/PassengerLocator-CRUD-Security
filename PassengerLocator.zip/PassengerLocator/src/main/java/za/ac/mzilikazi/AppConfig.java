package za.ac.mzilikazi;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.awt.datatransfer.Transferable;

/**
 * Created by Asavela on 2017/09/07.
 */
@Configuration
public class AppConfig {
    //@Bean
    //public TransferService transferService(){
       // return new za.ac.mzilikazi.Services.Impl.CouponServiceImpl();
   //}
}
